<?php
echo "abc";
?>